import 'package:corona/data/services.dart';

class DataTwo {
  Summary summary;
}
