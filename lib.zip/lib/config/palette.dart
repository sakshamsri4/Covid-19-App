import 'package:flutter/material.dart';

class Palette {
  static const Color primaryColor = Color(0xFF473F97);
}
